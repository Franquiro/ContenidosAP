var inputX1;
var inputOp;
var inputX2;

function operar(){
    inputX1 = document.querySelector("#x1");
    inputOp = document.querySelector("#op");
    inputX2 = document.querySelector("#x2");
    var x1 = parseFloat(inputX1.value);
    var x2 = parseFloat(inputX2.value);
    var op = inputOp.value;
    var operacion = String(x1)+op+x2+" = "
    if(op == "+"){
        var resultado = operacion+String(x1+x2);
        var tR = document.createElement("h2");
        tR.innerHTML = resultado;
        tR.setAttribute("style","color:#00ffff;");
        document.body.appendChild(tR);
        //document.getElementsByClassName("resultado")[0].innerHTML = String(x1+x2);
    }
    else if(op == "-"){
        var resultado = operacion+String(x1-x2);
        var tR = document.createElement("h2");
        tR.setAttribute("style","color:#00ffff;");
        tR.innerHTML = resultado;
        document.body.appendChild(tR);
        //document.getElementsByClassName("resultado")[0].innerHTML = String(x1-x2);
    }
    else if(op=="x"||op == "*"){
        var resultado = operacion+String(x1*x2);
        var tR = document.createElement("h2");
         // poner un color aleatorio
        var R = Math.random()*255; //guardo un valor aleatorio entre 0 y 255 para rojo
        var G = Math.random()*255; // idem para verde
        var B = Math.random()*255; // idem para azul
        
        //armo el texto de la propiedad.
        var color = "color:rgb("+R+","+G+","+B+");"
        //pongo el atributo de color al resultado:
        tR.setAttribute("style",color);
        tR.innerHTML = resultado;
        document.body.appendChild(tR);
        //document.getElementsByClassName("resultado")[0].innerHTML = String(x1*x2);
    }
    else{
        var resultado = operacion + String(x1/x2);
        var tR = document.createElement("h2");
        tR.setAttribute("style","color:#00ffff;");
        tR.innerHTML = resultado;
        document.body.appendChild(tR);
       
        //document.getElementsByClassName("resultado")[0].innerHTML = String(x1/x2);
    }
    
    console.log(x1,x2,op);
}